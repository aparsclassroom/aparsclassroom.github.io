const product = "acsenglishvar25";
const productName = "ACS-SoE Varsity, Medical, Engineering English Private Batch";
const productCode = "549";
const fix = 2000;
const pls = 1000;
const Platform = "Online";
const init = 0;