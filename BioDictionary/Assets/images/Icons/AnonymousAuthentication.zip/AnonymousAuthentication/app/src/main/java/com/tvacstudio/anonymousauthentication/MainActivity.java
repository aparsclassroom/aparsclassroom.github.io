package com.tvacstudio.anonymousauthentication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private FirebaseUser mCurrentUser;

    private TextView mFormFeedback;
    private ProgressBar mFormProgressBar;

    private EditText mEmailText;
    private EditText mPasswordText;

    private Button mLinkBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Initialize Firebase Auth
        mAuth = FirebaseAuth.getInstance();
        mCurrentUser = mAuth.getCurrentUser();
        setContentView(R.layout.activity_main);

        mFormFeedback = findViewById(R.id.form_feedback);
        mFormProgressBar = findViewById(R.id.form_progress_bar);

        mEmailText = findViewById(R.id.email_text);
        mPasswordText = findViewById(R.id.password_text);

        mLinkBtn = findViewById(R.id.link_btn);

        if(mCurrentUser == null){
            mFormProgressBar.setVisibility(View.VISIBLE);
            mAuth.signInAnonymously().addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    mFormFeedback.setVisibility(View.VISIBLE);
                    if(task.isSuccessful()){
                        mFormFeedback.setText("Signed in Anonymously");
                    } else {
                        mFormFeedback.setText("There was an error signing in");
                    }
                    mFormProgressBar.setVisibility(View.INVISIBLE);
                }
            });
        }

        mLinkBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = mEmailText.getText().toString();
                String password = mPasswordText.getText().toString();
                if(mCurrentUser != null){
                    if(!email.isEmpty() || !password.isEmpty()){
                        mFormProgressBar.setVisibility(View.VISIBLE);
                        AuthCredential credential = EmailAuthProvider.getCredential(email, password);
                        mCurrentUser.linkWithCredential(credential).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                mFormFeedback.setVisibility(View.VISIBLE);
                                if(task.isSuccessful()){
                                    mFormFeedback.setText("New Account Linked");
                                } else {
                                    mFormFeedback.setText("There was an error signing in");
                                }
                                mFormProgressBar.setVisibility(View.INVISIBLE);
                            }
                        });
                    }
                }
            }
        });

    }

    @Override
    public void onStart() {
        super.onStart();

    }

}
